module.exports = {
    googleClientID: '462620967027-5js2ofal4b7tes40r47oj5cod77bksl0.apps.googleusercontent.com',
    googleClientSecret: 'Nf7d2tjVKNJ3IWuIlpsakiiE',
    cookieKey: 'catdsfsdfs'
};